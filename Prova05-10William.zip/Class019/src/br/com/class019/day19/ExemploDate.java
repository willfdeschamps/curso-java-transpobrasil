package br.com.class019.day19;

public class ExemploDate {

}
